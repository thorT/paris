//
//  AppDelegate.h
//  DarkModelTool
//
//  Created by thor on 2019/9/26.
//  Copyright © 2019 thor. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

